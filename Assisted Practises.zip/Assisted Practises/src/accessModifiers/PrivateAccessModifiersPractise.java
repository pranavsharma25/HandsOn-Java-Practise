package accessModifiers;

class privateaccessmodifiers 
{ 
   private void display() 
    { 
        System.out.println("We are using private access modifier"); 
    } 
} 

public class PrivateAccessModifiersPractise {

	public static void main(String[] args) {
		
		System.out.println("Private Access Modifiers");
		
		privateaccessmodifiers  obj = new privateaccessmodifiers(); 
        

	}
}
	
