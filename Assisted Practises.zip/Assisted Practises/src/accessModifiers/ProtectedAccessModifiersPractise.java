package accessModifiers;


public class ProtectedAccessModifiersPractise {

		protected void display() 
	    { 
	        System.out.println("This is protected access modifier"); 
	    } 
	}


	