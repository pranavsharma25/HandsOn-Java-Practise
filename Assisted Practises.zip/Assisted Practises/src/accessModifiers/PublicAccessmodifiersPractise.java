package accessModifiers;

public class PublicAccessmodifiersPractise {

	public void display() 
    { 
        System.out.println("This is Public Access Modifier"); 
    } 
}


