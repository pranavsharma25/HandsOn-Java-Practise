package package2;

import accessModifiers.*;

public class ProtectedAccessModifierPractise2 extends ProtectedAccessModifiersPractise {

	public static void main(String[] args) {
		
		ProtectedAccessModifierPractise2 obj = new ProtectedAccessModifierPractise2();
		
		obj.display();

	}

}
