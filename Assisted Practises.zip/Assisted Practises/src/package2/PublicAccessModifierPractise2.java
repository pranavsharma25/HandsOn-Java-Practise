package package2;

import accessModifiers.*;

public class PublicAccessModifierPractise2 {

	public static void main(String[] args) {
		
		PublicAccessmodifiersPractise obj = new PublicAccessmodifiersPractise();
		
		obj.display();

	}

}
